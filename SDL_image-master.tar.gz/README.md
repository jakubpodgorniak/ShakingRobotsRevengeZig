This is a fork of [SDL_image](https://github.com/libsdl-org/SDL_image/), packaged for Zig. Unnecessary
files have been deleted, and the build system has been replaced with
`build.zig`.

Note: because of laziness and complacency, only a few common image formats of SDL image are supported here. make a pull request or open an issue if you need something!
